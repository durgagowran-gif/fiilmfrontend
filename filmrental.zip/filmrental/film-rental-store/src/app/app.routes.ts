import { Routes } from '@angular/router';

import { HomeComponent } from './pages/home/home';
import {  RegisterComponent } from './pages/register/register';
import { StaffDashboard } from './pages/staff-dashboard/staff-dashboard';
import { FilmsComponent } from './pages/films/films';
import { FilmDetailsComponent } from './pages/film-details/film-details';
import { PaymentComponent } from './pages/payment/payment';
import { RentalsComponent } from './pages/rentals/rentals';
import { PaymentsHistory } from './pages/paymentshistory/paymentshistory';
import { StaffFilmsComponent } from './pages/staff/films/staff-films/staff-films';
import { StaffFilmFormComponent } from './pages/staff/films/staff-film-form/staff-film-form';
import { StaffCategoriesComponent } from './pages/staff/categories/staff.categories/staff.categories';
import { StaffCategoryFormComponent } from './pages/staff/categories/staff.category-form/staff.category-form';
import { StaffCustomersComponent } from './pages/staff/customers/staff-customers/staff-customers';
import { StaffCustomerFormComponent } from './pages/staff/customers/staff-customers-form/staff-customers-form';
import { StaffInventoryComponent } from './pages/staff/inventory/staff-inventory/staff-inventory';
import { StaffInventoryFormComponent } from './pages/staff/inventory/staff-inventory-form/staff-inventory-form';
import { StaffManagementComponent } from './pages/staff/staff-manage/staff-management/staff-management';
import { StaffFormComponent } from './pages/staff/staff-manage/staff-form/staff-form';
import { ProfileComponent } from './pages/profile/profile.component/profile.component';
import { StaffActorsComponent } from './pages/staff/actors/staff-actors.component/staff-actors.component';
import { StaffActorFormComponent } from './pages/staff/actors/staff-actors-form/staff-actors-form';
import { StaffPaymentsComponent } from './pages/staff/payments/payments.component/payments.component';
import { StaffRentalsComponent } from './pages/staff/rentals/rentals.component/rentals.component';
import { StaffProfileComponent } from './pages/staff/profile/staff-profile/staff-profile';
import { LoginComponent } from './pages/login/login';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  { path: 'home', component: HomeComponent },
  { path: 'films', component: FilmsComponent },
  { path: 'film/:id', component: FilmDetailsComponent },

  { path: 'login', component: LoginComponent },

  { path: 'payment', component: PaymentComponent },
  { path: 'payments', component: PaymentsHistory },   // ✅ FIX
  { path: 'rentals', component: RentalsComponent },

  { path: 'staff/dashboard', component: StaffDashboard },
  { path: 'staff/films', component: StaffFilmsComponent },
{ path: 'staff/films/add', component: StaffFilmFormComponent },
{ path: 'staff/films/edit/:id', component: StaffFilmFormComponent },
{ path: 'staff/categories', component: StaffCategoriesComponent },
{ path: 'staff/categories/add', component: StaffCategoryFormComponent },
{ path: 'staff/categories/edit/:id', component: StaffCategoryFormComponent },
{ path: 'staff/customers', component: StaffCustomersComponent },
{ path: 'staff/customers/add', component: StaffCustomerFormComponent },
{ path: 'staff/customers/edit/:id', component: StaffCustomerFormComponent},
{ path: 'staff/inventory', component: StaffInventoryComponent },
{ path: 'staff/inventory/add', component: StaffInventoryFormComponent },
{ path: 'staff/inventory/edit/:id', component: StaffInventoryFormComponent },
{ path: 'staff/manage', component: StaffManagementComponent },
{ path: 'staff/manage/add', component: StaffFormComponent },
{ path: 'staff/manage/edit/:id', component: StaffFormComponent },
{ path: 'profile', component: ProfileComponent },
{ path: 'staff/actors', component: StaffActorsComponent },
{ path: 'staff/actors/add', component: StaffActorFormComponent },
{ path: 'staff/actors/edit/:id', component: StaffActorFormComponent },
{ path: 'register', component: RegisterComponent },
{ path: 'staff/rentals', component: StaffRentalsComponent },
{ path: 'staff/payments', component: StaffPaymentsComponent },
{ path: 'staff/profile', component: StaffProfileComponent },
{ path: '', redirectTo: 'home', pathMatch: 'full' },
 

];
