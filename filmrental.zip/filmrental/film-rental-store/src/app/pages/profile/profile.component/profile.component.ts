import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { RentalService } from '../../../shared/services/rental.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule
  ],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent {

  customer = {
    id: 'CUST101',
    name: 'John Doe',
    email: 'john@mail.com',
    store: 'Main Store'
  };

  displayedColumns = ['film', 'rentalDate', 'returnDate', 'status'];

  constructor(public rentalService: RentalService) {}
}
