import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-staff-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule
  ],
  templateUrl: './staff-dashboard.html',
  styleUrls: ['./staff-dashboard.scss']
})
export class StaffDashboard {

  constructor(private router: Router) {}

  go(module: string) {

    if (module === 'films') {
      this.router.navigate(['/staff/films']);
    }

    if (module === 'categories') {
      this.router.navigate(['/staff/categories']);
    }

    if (module === 'actors') {
      this.router.navigate(['/staff/actors']);
    }

    if (module === 'customers') {
      this.router.navigate(['/staff/customers']);
    }

    if (module === 'inventory') {
      this.router.navigate(['/staff/inventory']);
    }

    if (module === 'staff') {
      this.router.navigate(['/staff/manage']);
    }

    // ✅ NEW: STAFF RENTALS
    if (module === 'rentals') {
      this.router.navigate(['/staff/rentals']);
    }

    // ✅ NEW: STAFF PAYMENTS
    if (module === 'payments') {
      this.router.navigate(['/staff/payments']);
    }
  }
}
