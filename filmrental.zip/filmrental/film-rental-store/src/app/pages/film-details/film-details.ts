import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatTableModule } from '@angular/material/table';

import { FilmService } from '../../shared/services/film.service';
import { RentalService } from '../../shared/services/rental.service';

@Component({
  selector: 'app-film-details',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatChipsModule,
    MatTableModule
  ],
  templateUrl: './film-details.html',
  styleUrls: ['./film-details.scss']
})
export class FilmDetailsComponent implements OnInit {

  film: any;
  selectedCopy: number | null = null;

  displayedColumns = ['store', 'available', 'action'];

  constructor(
    private route: ActivatedRoute,
    private filmService: FilmService,
    private router: Router,
    private flow: RentalService

  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.film = this.filmService.getFilmDetails(id);
  }

  selectCopy(copyId: number) {
    this.selectedCopy = copyId;
  }

  rentNow() {
  this.flow.selectedFilm = this.film;
  this.flow.selectedCopy = this.selectedCopy;
  this.router.navigate(['/payment']);
}

}
