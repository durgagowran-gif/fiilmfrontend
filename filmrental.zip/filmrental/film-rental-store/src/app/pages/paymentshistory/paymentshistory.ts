import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';

import { RentalService } from '../../shared/services/rental.service';
import { AuthService } from '../../shared/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatCardModule
  ],
  templateUrl: './paymentshistory.html',
  styleUrls: ['./paymentshistory.scss']
})
export class PaymentsHistory {

  displayedColumns = ['id', 'amount', 'date', 'status'];
constructor(
    public rentalService: RentalService,
    private auth: AuthService,
    private router: Router
  ) {
    // 🔐 SIGN-IN CHECK
    if (!this.auth.isLoggedIn) {
      this.router.navigate(['/login']);
    }
  }
}