import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Paymentshistory } from './paymentshistory';

describe('Paymentshistory', () => {
  let component: Paymentshistory;
  let fixture: ComponentFixture<Paymentshistory>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Paymentshistory]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Paymentshistory);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
