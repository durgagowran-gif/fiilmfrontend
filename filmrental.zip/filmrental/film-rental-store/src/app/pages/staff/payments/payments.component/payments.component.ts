import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';

@Component({
  selector: 'app-staff-payments',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule
  ],
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class StaffPaymentsComponent {

  displayedColumns = [
    'id',
    'customer',
    'amount',
    'date',
    'status'
  ];

  payments = [
    {
      id: 'PAY5001',
      customer: 'John Doe',
      amount: 120,
      date: new Date(),
      status: 'PAID'
    },
    {
      id: 'PAY5002',
      customer: 'Jane Smith',
      amount: 150,
      date: new Date(),
      status: 'PAID'
    }
  ];
}
