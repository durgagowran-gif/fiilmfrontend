import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-staff-customers',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule
  ],
  templateUrl: './staff-customers.html',
  styleUrls: ['./staff-customers.scss']
})
export class StaffCustomersComponent {

  searchText = '';

  customers = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john@mail.com',
      city: 'Chennai',
      store: 'Main Store'
    },
    {
      id: 2,
      name: 'Jane Smith',
      email: 'jane@mail.com',
      city: 'Bangalore',
      store: 'Central Store'
    }
  ];

  displayedColumns = ['id', 'name', 'email', 'city', 'store', 'action'];

  constructor(private router: Router) {}

  addCustomer() {
    this.router.navigate(['/staff/customers/add']);
  }

  editCustomer(id: number) {
    this.router.navigate(['/staff/customers/edit', id]);
  }
}
