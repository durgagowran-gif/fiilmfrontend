import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffCustomersForm } from './staff-customers-form';

describe('StaffCustomersForm', () => {
  let component: StaffCustomersForm;
  let fixture: ComponentFixture<StaffCustomersForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffCustomersForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffCustomersForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
