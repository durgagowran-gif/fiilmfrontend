import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffCustomers } from './staff-customers';

describe('StaffCustomers', () => {
  let component: StaffCustomers;
  let fixture: ComponentFixture<StaffCustomers>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffCustomers]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffCustomers);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
