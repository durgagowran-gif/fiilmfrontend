import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'app-staff-customer-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule
  ],
  templateUrl: './staff-customers-form.html',
  styleUrls: ['./staff-customers-form.scss']
})
export class StaffCustomerFormComponent implements OnInit {

  isEdit = false;

  customer = {
    firstName: '',
    lastName: '',
    email: '',
    active: true,
    store: '',
    address: {
      address: '',
      district: '',
      city: '',
      country: '',
      postalCode: '',
      phone: ''
    }
  };

  stores = ['Chennai Store', 'Bangalore Store'];
  cities = ['Chennai', 'Bangalore'];
  countries = ['India'];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEdit = true;

      // MOCK EXISTING CUSTOMER (replace with backend later)
      this.customer = {
        firstName: 'John',
        lastName: 'Doe',
        email: 'john@mail.com',
        active: true,
        store: 'Chennai Store',
        address: {
          address: 'Street 1',
          district: 'Central',
          city: 'Chennai',
          country: 'India',
          postalCode: '600001',
          phone: '9876543210'
        }
      };
    }
  }

  save() {
    alert(this.isEdit ? 'Customer updated (UI only)' : 'Customer created (UI only)');
    this.router.navigate(['/staff/customers']);
  }
}
