import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-staff-inventory-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './staff-inventory-form.html',
  styleUrls: ['./staff-inventory-form.scss']
})
export class StaffInventoryFormComponent implements OnInit {

  isEdit = false;

  inventory = {
    film: '',
    store: '',
    availableCopies: null as number | null
  };

  // Mock data (replace with backend later)
  films = ['Inception', 'Interstellar', 'The Dark Knight'];
  stores = ['Chennai Store', 'Bangalore Store'];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEdit = true;

      // MOCK EXISTING INVENTORY
      this.inventory = {
        film: 'Inception',
        store: 'Chennai Store',
        availableCopies: 3
      };
    }
  }

  save() {
    alert(this.isEdit ? 'Inventory updated (UI only)' : 'Inventory created (UI only)');
    this.router.navigate(['/staff/inventory']);
  }
}
