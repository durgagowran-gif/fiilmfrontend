import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffInventoryForm } from './staff-inventory-form';

describe('StaffInventoryForm', () => {
  let component: StaffInventoryForm;
  let fixture: ComponentFixture<StaffInventoryForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffInventoryForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffInventoryForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
