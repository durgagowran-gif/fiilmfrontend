import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-staff-inventory',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule
  ],
  templateUrl: './staff-inventory.html',
  styleUrls: ['./staff-inventory.scss']
})
export class StaffInventoryComponent {

  displayedColumns = ['id', 'film', 'store', 'available', 'action'];

  inventory = [
    { id: 1, film: 'Inception', store: 'Chennai Store', available: 3 },
    { id: 2, film: 'Interstellar', store: 'Bangalore Store', available: 2 }
  ];

  constructor(private router: Router) {}

  addInventory() {
    this.router.navigate(['/staff/inventory/add']);
  }

  editInventory(id: number) {
    this.router.navigate(['/staff/inventory/edit', id]);
  }
}
