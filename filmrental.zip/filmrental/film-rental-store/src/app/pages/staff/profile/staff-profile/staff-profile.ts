import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { AuthService } from '../../../../shared/services/auth.service';

@Component({
  selector: 'app-staff-profile',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule
  ],
  templateUrl: './staff-profile.html',
  styleUrls: ['./staff-profile.scss']
})
export class StaffProfileComponent implements OnInit {

  staff = {
    staffId: 'STAFF101',
    name: 'Admin User',
    email: 'admin@store.com',
    store: 'Chennai Store',
    role: 'Manager'
  };

  constructor(
    public auth: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // 🚫 Block customers
    if (this.auth.role !== 'STAFF') {
      this.router.navigate(['/home']);
    }
  }
}
