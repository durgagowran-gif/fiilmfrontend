import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-staff-categories',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule
  ],
  templateUrl: './staff.categories.html',
  styleUrls: ['./staff.categories.scss']
})
export class StaffCategoriesComponent {

  displayedColumns = ['id', 'name', 'action'];

  categories = [
    { id: 1, name: 'Action' },
    { id: 2, name: 'Sci-Fi' },
    { id: 3, name: 'Drama' }
  ];

  constructor(private router: Router) {}

  addCategory() {
    this.router.navigate(['/staff/categories/add']);
  }

  editCategory(id: number) {
    this.router.navigate(['/staff/categories/edit', id]);
  }
}
