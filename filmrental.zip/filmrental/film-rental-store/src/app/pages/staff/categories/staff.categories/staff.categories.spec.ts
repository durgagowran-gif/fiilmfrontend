import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffCategories } from './staff.categories';

describe('StaffCategories', () => {
  let component: StaffCategories;
  let fixture: ComponentFixture<StaffCategories>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffCategories]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffCategories);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
