import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-staff-category-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule
  ],
  templateUrl: './staff.category-form.html',
  styleUrls: ['./staff.category-form.scss']
})
export class StaffCategoryFormComponent implements OnInit {

  isEdit = false;

  category = {
    name: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      // 🧪 mock existing data
      this.category.name = 'Action';
    }
  }

  save() {
    alert(this.isEdit ? 'Category updated (UI only)' : 'Category added (UI only)');
    this.router.navigate(['/staff/categories']);
  }
}
