import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffCategoryForm } from './staff.category-form';

describe('StaffCategoryForm', () => {
  let component: StaffCategoryForm;
  let fixture: ComponentFixture<StaffCategoryForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffCategoryForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffCategoryForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
