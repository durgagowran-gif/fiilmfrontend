import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';

@Component({
  selector: 'app-staff-rentals',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule
  ],
  templateUrl: './rentals.component.html',
  styleUrls: ['./rentals.component.scss']
})
export class StaffRentalsComponent {

  displayedColumns = [
    'id',
    'customer',
    'film',
    'store',
    'rentalDate',
    'returnDate',
    'status'
  ];

  rentals = [
    {
      id: 'RENT1001',
      customer: 'John Doe',
      film: 'Inception',
      store: 'Chennai Store',
      rentalDate: new Date(),
      returnDate: new Date(Date.now() + 5 * 86400000),
      status: 'ACTIVE'
    },
    {
      id: 'RENT1002',
      customer: 'Jane Smith',
      film: 'Interstellar',
      store: 'Bangalore Store',
      rentalDate: new Date(),
      returnDate: new Date(Date.now() + 3 * 86400000),
      status: 'RETURNED'
    }
  ];
}
