import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-staff-film-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './staff-film-form.html',
  styleUrls: ['./staff-film-form.scss']
})
export class StaffFilmFormComponent implements OnInit {

  isEdit = false;

  film = {
    title: '',
    description: '',
    releaseYear: null as number | null,
    language: '',
    originalLanguage: '',
    rentalDuration: null as number | null,
    rentalRate: null as number | null,
    length: null as number | null,
    rating: null as number | null
  };

  languages = ['English', 'Tamil', 'Hindi'];
  ratings = [1, 2, 3, 4, 5];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEdit = true;

      // MOCK EXISTING FILM (replace with backend later)
      this.film = {
        title: 'Inception',
        description: 'A thief who steals corporate secrets through dream-sharing.',
        releaseYear: 2010,
        language: 'English',
        originalLanguage: 'English',
        rentalDuration: 5,
        rentalRate: 120,
        length: 148,
        rating: 5
      };
    }
  }

  save() {
    alert(this.isEdit ? 'Film updated (UI only)' : 'Film created (UI only)');
    this.router.navigate(['/staff/films']);
  }
}
