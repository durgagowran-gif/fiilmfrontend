import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-staff-films',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule
  ],
  templateUrl: './staff-films.html',
  styleUrls: ['./staff-films.scss']
})
export class StaffFilmsComponent {

  searchText = '';

  films = [
    { id: 1, title: 'Inception', language: 'English', rate: 120 },
    { id: 2, title: 'Interstellar', language: 'English', rate: 150 }
  ];

  displayedColumns = ['id', 'title', 'language', 'rate', 'action'];

  constructor(private router: Router) {}

  addFilm() {
    this.router.navigate(['/staff/films/add']);
  }

  editFilm(id: number) {
    this.router.navigate(['/staff/films/edit', id]);
  }
}
