import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffFilmForm } from './staff-film-form';

describe('StaffFilmForm', () => {
  let component: StaffFilmForm;
  let fixture: ComponentFixture<StaffFilmForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffFilmForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffFilmForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
