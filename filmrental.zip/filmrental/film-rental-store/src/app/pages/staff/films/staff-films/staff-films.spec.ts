import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffFilms } from './staff-films';

describe('StaffFilms', () => {
  let component: StaffFilms;
  let fixture: ComponentFixture<StaffFilms>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffFilms]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffFilms);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
