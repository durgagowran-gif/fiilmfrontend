import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'app-staff-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule
  ],
  templateUrl: './staff-form.html',
  styleUrls: ['./staff-form.scss']
})
export class StaffFormComponent implements OnInit {

  isEdit = false;

  staff = {
    firstName: '',
    lastName: '',
    email: '',
    username: '',
    password: '',
    active: true,
    store: '',
    address: {
      address: '',
      district: '',
      city: '',
      country: '',
      postalCode: '',
      phone: ''
    }
  };

  stores = ['Chennai Store', 'Bangalore Store'];
  cities = ['Chennai', 'Bangalore'];
  countries = ['India'];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEdit = true;

      // MOCK STAFF (replace with backend later)
      this.staff = {
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@store.com',
        username: 'admin',
        password: '',
        active: true,
        store: 'Chennai Store',
        address: {
          address: 'Main Street',
          district: 'Central',
          city: 'Chennai',
          country: 'India',
          postalCode: '600001',
          phone: '9999999999'
        }
      };
    }
  }

  save() {
    alert(this.isEdit ? 'Staff updated (UI only)' : 'Staff created (UI only)');
    this.router.navigate(['/staff/dashboard']);
  }
}
