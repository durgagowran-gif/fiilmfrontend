
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-staff-management',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule
  ],
  templateUrl: './staff-management.html',
  styleUrls: ['./staff-management.scss']
})
export class StaffManagementComponent {

  displayedColumns = ['id', 'name', 'email', 'store', 'action'];

  staffList = [
    {
      id: 1,
      name: 'Admin One',
      email: 'admin1@store.com',
      store: 'Chennai Store'
    },
    {
      id: 2,
      name: 'Admin Two',
      email: 'admin2@store.com',
      store: 'Bangalore Store'
    }
  ];

  constructor(private router: Router) {}

  addStaff() {
    this.router.navigate(['/staff/manage/add']);
  }

  editStaff(id: number) {
    this.router.navigate(['/staff/manage/edit', id]);
  }
}
