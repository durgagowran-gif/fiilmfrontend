import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffActorsForm } from './staff-actors-form';

describe('StaffActorsForm', () => {
  let component: StaffActorsForm;
  let fixture: ComponentFixture<StaffActorsForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffActorsForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffActorsForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
