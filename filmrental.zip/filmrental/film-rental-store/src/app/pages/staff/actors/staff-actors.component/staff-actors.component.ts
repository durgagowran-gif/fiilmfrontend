import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-staff-actors',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule
  ],
  templateUrl: './staff-actors.component.html',
  styleUrls: ['./staff-actors.component.scss']
})
export class StaffActorsComponent {

  searchText = '';

  actors = [
    { id: 1, firstName: 'Leonardo', lastName: 'DiCaprio' },
    { id: 2, firstName: 'Christian', lastName: 'Bale' },
    { id: 3, firstName: 'Matthew', lastName: 'McConaughey' }
  ];

  displayedColumns = ['id', 'firstName', 'lastName', 'action'];

  constructor(private router: Router) {}

  get filteredActors() {
    if (!this.searchText) return this.actors;

    return this.actors.filter(a =>
      (a.firstName + ' ' + a.lastName)
        .toLowerCase()
        .includes(this.searchText.toLowerCase())
    );
  }

  addActor() {
    this.router.navigate(['/staff/actors/add']);
  }

  editActor(id: number) {
    this.router.navigate(['/staff/actors/edit', id]);
  }
}
