import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-staff-actor-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule
  ],
  templateUrl: './staff-actors-form.html',
  styleUrls: ['./staff-actors-form.scss']
})
export class StaffActorFormComponent implements OnInit {

  isEdit = false;

  actor = {
    firstName: '',
    lastName: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEdit = true;
      this.actor = {
        firstName: 'Leonardo',
        lastName: 'DiCaprio'
      };
    }
  }

  save() {
    alert(this.isEdit ? 'Actor updated (UI only)' : 'Actor added (UI only)');
    this.router.navigate(['/staff/actors']);
  }
}
