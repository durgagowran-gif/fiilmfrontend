import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffActorsComponent } from './staff-actors.component';

describe('StaffActorsComponent', () => {
  let component: StaffActorsComponent;
  let fixture: ComponentFixture<StaffActorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffActorsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffActorsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
