import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatRadioModule } from '@angular/material/radio';
import { RentalService } from '../../shared/services/rental.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatRadioModule
  ],
  templateUrl: './payment.html',
  styleUrls: ['./payment.scss']
})
export class PaymentComponent {

  paymentMethod = 'CARD';

  constructor(
    public flow: RentalService,
    private router: Router
  ) {}

  payNow() {
    // MOCK PAYMENT
    const payment = {
      id: 'PAY' + Math.floor(Math.random() * 10000),
      amount: this.flow.selectedFilm.rentalRate,
      date: new Date(),
      status: 'PAID'
    };

    this.flow.lastPayment = payment;
    this.flow.payments.push(payment);

    // CREATE RENTAL ONLY AFTER PAYMENT
    const rental = {
      id: 'RENT' + Math.floor(Math.random() * 10000),
      film: this.flow.selectedFilm.title,
      copy: this.flow.selectedCopy,
      rentalDate: new Date(),
      returnDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      status: 'ACTIVE'
    };

    this.flow.lastRental = rental;
    this.flow.rentals.push(rental);

    this.router.navigate(['/rentals']);
  }
}
