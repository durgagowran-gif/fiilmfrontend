import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatTabsModule } from '@angular/material/tabs';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../shared/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTabsModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule 
  ],
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})
export class LoginComponent {

  customerId = '';
  customerEmail = '';

  staffEmail = '';
  staffPassword = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  // ✅ CUSTOMER LOGIN
  loginCustomer() {
    if (!this.customerId || !this.customerEmail) {
      alert('Enter Customer ID and Email');
      return;
    }

    this.auth.loginAsCustomer();
    this.router.navigate(['/home']);
  }

  // ✅ STAFF LOGIN
  loginStaff() {
    if (!this.staffEmail || !this.staffPassword) {
      alert('Enter Staff credentials');
      return;
    }

    this.auth.loginAsStaff();
    this.router.navigate(['/staff/dashboard']);
  }
}
