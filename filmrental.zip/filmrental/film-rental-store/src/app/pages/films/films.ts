import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';

import { FilmService } from '../../shared/services/film.service';

@Component({
  selector: 'app-films',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatSidenavModule,
    MatSelectModule,
    MatSliderModule,
    MatCheckboxModule
  ],
  templateUrl: './films.html',
  styleUrls: ['./films.scss']
})
export class FilmsComponent implements OnInit {

  allFilms: any[] = [];
  films: any[] = [];

  // SEARCH
  searchText = '';

  // FILTER MODELS (BACKEND-READY)
  yearRange = { min: 2000, max: 2024 };
  priceRange = { min: 0, max: 500 };

  selectedLanguage = '';
  selectedRating: number | null = null;
  selectedCategories: string[] = [];

  // FILTER OPTIONS (mock, backend-ready)
  languages = ['English', 'Tamil', 'Hindi'];
  ratings = [1, 2, 3, 4, 5];
  categories = ['Action', 'Drama', 'Comedy', 'Sci-Fi'];

  constructor(
    private filmService: FilmService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.filmService.getAllFilms().subscribe(data => {
      this.allFilms = data;
      this.films = data;
    });
  }

  applyFilters() {
    this.films = this.allFilms.filter(f => {

      const searchMatch =
        !this.searchText ||
        f.title.toLowerCase().includes(this.searchText.toLowerCase());

      const languageMatch =
        !this.selectedLanguage || f.language === this.selectedLanguage;

      const ratingMatch =
        this.selectedRating === null || f.rating >= this.selectedRating;

      const yearMatch =
        f.releaseYear >= this.yearRange.min &&
        f.releaseYear <= this.yearRange.max;

      const priceMatch =
        f.rentalRate >= this.priceRange.min &&
        f.rentalRate <= this.priceRange.max;

      const categoryMatch =
        this.selectedCategories.length === 0 ||
        this.selectedCategories.includes(f.genre);

      return (
        searchMatch &&
        languageMatch &&
        ratingMatch &&
        yearMatch &&
        priceMatch &&
        categoryMatch
      );
    });
  }

  // 🔧 SLIDER HANDLERS (THIS FIXES BLUE SLIDER ISSUE)
  onYearChange(event: any) {
    this.yearRange.max = event.target.value;
    this.applyFilters();
  }

  onPriceChange(event: any) {
    this.priceRange.max = event.target.value;
    this.applyFilters();
  }

  toggleCategory(category: string) {
    const index = this.selectedCategories.indexOf(category);
    index === -1
      ? this.selectedCategories.push(category)
      : this.selectedCategories.splice(index, 1);
    this.applyFilters();
  }

  goToDetails(id: number) {
    this.router.navigate(['/film', id]);
  }
}
