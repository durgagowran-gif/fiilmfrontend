import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';

import { FilmService } from '../../shared/services/film.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule
  ],
  templateUrl: './home.html',
  styleUrls: ['./home.scss']
})
export class HomeComponent implements OnInit {

  films: any[] = [];

  constructor(
    private filmService: FilmService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.filmService.getAllFilms().subscribe(data => {
      this.films = data;
    });
  }

  goToDetails(id: number) {
    this.router.navigate(['/film', id]);
  }

  goToRent(id: number) {
    this.router.navigate(['/film', id]);
  }
}
