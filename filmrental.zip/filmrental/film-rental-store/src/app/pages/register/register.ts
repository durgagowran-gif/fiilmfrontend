import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class RegisterComponent {

  customer = {
    firstName: '',
    lastName: '',
    email: '',
    password: '',          // UI only
    active: true,
    store: '',
    address: {
      address: '',
      district: '',
      city: '',
      country: '',
      postalCode: '',
      phone: ''
    }
  };

  stores = ['Chennai Store', 'Bangalore Store'];
  cities = ['Chennai', 'Bangalore'];
  countries = ['India'];

  constructor(private router: Router) {}

  register() {
    alert('Customer registered (UI only)');
    this.router.navigate(['/login']);
  }
}
