import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';

import { RentalService } from '../../shared/services/rental.service';

@Component({
  selector: 'app-rentals',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule,
    MatIconModule
  ],
  templateUrl: './rentals.html',
  styleUrls: ['./rentals.scss']
})
export class RentalsComponent {

  displayedColumns = ['film', 'rentalDate', 'returnDate', 'status'];

  constructor(public flow: RentalService) {}
}
