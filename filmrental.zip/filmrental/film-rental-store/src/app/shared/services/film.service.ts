import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class FilmService {

  private apiUrl = `${environment.apiBaseUrl}/films`;

  // 🧪 MOCK DATA (fallback)
  private mockFilms = [
    {
      id: 1,
      title: 'Inception',
      genre: 'Sci-Fi',
      rating: 4.8,
      language: 'English',
      price: 120,
      poster: 'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg'
    },
    {
      id: 2,
      title: 'Interstellar',
      genre: 'Sci-Fi',
      rating: 4.7,
      language: 'English',
      price: 150,
      poster: 'https://image.tmdb.org/t/p/w500/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg'
    }
  ];

  constructor(private http: HttpClient) {}

  // 🔥 BACKEND: GET ALL FILMS
  getAllFilms(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl).pipe(
      catchError(err => {
        console.warn('Backend not available, using mock films');
        return of(this.mockFilms);
      })
    );
  }

  // 🔥 BACKEND: GET FILM BY ID
  getFilmById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(
      catchError(err => {
        console.warn('Backend not available, using mock film');
        return of(this.mockFilms.find(f => f.id === id));
      })
    );
  }

  // 🔥 BACKEND: FILM DETAILS
  getFilmDetails(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(
      catchError(() =>
        of({
          id,
          title: 'Inception',
          description: 'A thief who steals corporate secrets through dream-sharing.',
          categories: ['Sci-Fi', 'Action'],
          actors: ['Leonardo DiCaprio'],
          language: 'English',
          releaseYear: 2010,
          length: 148,
          rentalRate: 120,
          rentalDuration: 5,
          poster: 'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg',
          inventory: [
            { store: 'Chennai Store', available: 2, copies: [101, 102] }
          ]
        })
      )
    );
  }

  // 🔍 SEARCH (FRONTEND FILTER)
  searchFilms(query: string, films: any[]) {
    if (!query) return films;

    return films.filter(f =>
      f.title.toLowerCase().includes(query.toLowerCase()) ||
      f.genre?.toLowerCase().includes(query.toLowerCase())
    );
  }
}
