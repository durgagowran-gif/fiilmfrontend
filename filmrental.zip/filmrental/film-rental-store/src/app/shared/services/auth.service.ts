import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {

  isLoggedIn = false;
  role: 'CUSTOMER' | 'STAFF' | null = null;

  loginAsCustomer() {
    this.isLoggedIn = true;
    this.role = 'CUSTOMER';
  }

  loginAsStaff() {
    this.isLoggedIn = true;
    this.role = 'STAFF';
  }
  
  logout() {
    this.isLoggedIn = false;
    this.role = null;
  }
}
