import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export class ApiService {
  protected baseUrl = environment.apiBaseUrl;

  constructor(protected http: HttpClient) {}
}
