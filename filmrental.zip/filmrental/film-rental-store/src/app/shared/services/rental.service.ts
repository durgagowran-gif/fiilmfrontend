import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class RentalService {

  selectedFilm: any = null;
  selectedCopy: number | null = null;

  lastPayment: any = null;
  lastRental: any = null;

  rentals: any[] = [];
  payments: any[] = [];

  reset() {
    this.selectedFilm = null;
    this.selectedCopy = null;
  }
}
