export interface Film {
  filmId: number;
  title: string;
  description: string;
  releaseYear: number;
  rentalRate: number;
  length: number;
  language: string;
}
