export interface Payment {
  paymentId: number;
  amount: number;
  paymentDate: Date;
}
