export interface Rental {
  rentalId: number;
  rentalDate: Date;
  returnDate: Date;
  filmTitle: string;
}
