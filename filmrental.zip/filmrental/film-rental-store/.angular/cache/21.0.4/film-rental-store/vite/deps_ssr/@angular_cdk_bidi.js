import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-4QGJFD4X.js";
import "./chunk-WCYETMVC.js";
import "./chunk-C27DBZK2.js";
import "./chunk-2UVUUPPC.js";
import "./chunk-K54IFBYX.js";
import "./chunk-6DU2HRTW.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
